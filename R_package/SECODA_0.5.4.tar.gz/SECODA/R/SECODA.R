# SECODA anomaly detection algorithm
# Dr. Ralph Foorthuis
# www.foorthuis.nl
# 2016, 2017, 2018, 2019 (20190228)
# GNU Affero General Public License version 3
# For research regarding SECODA see:
# - Foorthuis, R.M. (2017). "SECODA: Segmentation- and Combination-Based Detection of Anomalies." In: Proceedings of the 4th IEEE International Conference on Data Science and Advanced Analytics (DSAA 2017), Tokyo, Japan.
# - Foorthuis, R.M. (2019). "All or In-cloud: How the Identification of Six Types of Anomalies is Affected by the Discretization Method." In: Atzmueller M., Duivesteijn W. (eds) Artificial Intelligence. BNAIC 2018. Springer, Communications in Computer and Information Science, Vol. 1021, pp 25-42. DOI: 10.1007/978-3-030-31978-6_3
# See this paper for more information about the types of anomalies:
# - Foorthuis, R.M. (2018). "A Typology of Data Anomalies." In: Springer CCIS 854, Proceedings of the 17th International Conference on Information Processing and Management of Uncertainty in Knowledge-Based Systems (IPMU 2018), Cádiz, Spain. DOI: 10.1007/978-3-319-91476-3_3.


#' @title SECODA
#'
#' @description \emph{Segmentation- and Combination-Based Detection of Anomalies}
#' @description SECODA is a novel general-purpose unsupervised non-parametric anomaly detection algorithm for datasets containing continuous and/or categorical attributes. The method, in its standard mode, is guaranteed to identify cases with unique or sparse combinations of attribute values.
#' @description SECODA identifies different types of anomalies (see Foorthuis 2018 for more information about anomaly types):
#' @description \itemize{
#'   \item \strong{  I. Extreme value anomaly}: A case with an extremely high or low (or otherwise rare) value. A case can be an anomaly on one individual attribute, so \emph{extreme value anomalies} do not depend on relationships between attributes.
#'   \item \strong{ II. Rare class anomaly}: A case with a rare class value on one or multiple categorical attributes. A case can be an anomaly on one individual attribute, so \emph{sparse class anomalies} do not depend on relationships between attributes.
#'   \item \strong{III. Simple mixed data anomaly}: A case that is both a Type I and Type II anomaly, i.e. with at least one extreme value and one rare class. This requires deviant values for at least two attributes, each anomalous in its own right. These can thus be analyzed separately; analyzing the attributes jointly is unnecessary because the case is not anomalous in terms of a combination of values.
#'   \item \strong{ IV. Multidimensional numerical anomaly}: A case that does not conform to the general pattern when multiple numerical attributes are taken into account jointly, but does not have extreme values for any of its individual numerical attributes.
#'   \item \strong{  V. Multidimensional rare class anomaly}: A case with a rare combination of class values. A minimum of two substantive categorical attributes needs to be analyzed jointly to discover a multidimensional rare class anomaly (at least in datasets with independent data points).
#'   \item \strong{ VI. Multidimensional mixed data anomaly}: A case with a categorical value or a combination of categorical values that in itself is not rare in the dataset as a whole, but is only rare in its neighborhood (numerical area).
#' }
#' @description The algorithm uses the histogram-based approach to assess the density. The concatenation trick – which combines discretized continuous attributes and categorical attributes into a new variable – is used to determine the joint density distribution. In combination with recursive discretization this captures complex relationships between attributes and avoids discretization error. A pruning heuristic as well as exponentially increasing weights and arity are employed to speed up the analysis.
#' @description The user is advised to first try the standard HighDimMode setting ("NO") for low-dimensional datasets. If the algorithm returns the warning that the given fraction of anomalies was already reached in first iteration, this is probably due to the curse of dimensionality. The user should consequently re-run the analysis with a HighDimMode setting for higher-dimensional datasets (first "CA", then "IN"). Note that the "IN" setting does not guarantee that unique attribute value combinations are identified as anomalies. See below for more information on the HighDimMode options.
#'
#' @author Ralph Foorthuis
#' @references Foorthuis, R.M. (2019). \emph{All or In-cloud: How the Identification of Six Types of Anomalies is Affected by the Discretization Method}. In: Atzmueller M., Duivesteijn W. (eds) Artificial Intelligence. BNAIC 2018. Springer, Communications in Computer and Information Science, Vol. 1021, pp 25-42. DOI: 10.1007/978-3-030-31978-6_3.
#' @references Foorthuis, R.M. (2018). \emph{A Typology of Data Anomalies}. In: Springer CCIS 854, Proceedings of the 17th International Conference on Information Processing and Management of Uncertainty in Knowledge-Based Systems (IPMU 2018), Cádiz, Spain. DOI: 10.1007/978-3-319-91476-3_3.
#' @references Foorthuis, R.M. (2017). \emph{SECODA: Segmentation- and Combination-Based Detection of Anomalies}. In: Proceedings of the 4th IEEE International Conference on Data Science and Advanced Analytics (DSAA 2017), Tokyo, Japan.
#' @references Foorthuis, R.M. (2017). \emph{Anomaly Detection with SECODA}. Poster Presentation at the 4th IEEE International Conference on Data Science and Advanced Analytics (DSAA 2017), Tokyo, Japan.
#' @references Foorthuis, R.M. (2017). \emph{The SECODA Algorithm for the Detection of Anomalies in Sets with Mixed Data}. Presentation.
#' @references SECODA example data files and R code: \url{http://www.foorthuis.nl}
#' @param datset The dataset that is being analyzed for anomalies. Datset should be a data.frame. SECODA treats numeric and categorical data differently. Before running SECODA() make sure that the data types are declared correctly. Numeric data should be 'integer' or 'numeric', whereas categorical data should be 'factor', 'logical' or 'character'.
#' @param BinningMethod The method used for unsupervised discretization. \itemize{
#'   \item "EW" for equiwidth (equal interval) binning.
#'   \item "ED" for equidepth (equal frequency) binning.
#'   }
#' @param HighDimMode The approach to deal with low- or high-dimensionality. This setting may be changed when SECODA displays a warning message that there may be too many variables in the set, which is triggered if the algorithm already reached the convergence criterion after 1 iteration. \itemize{
#'  \item "NO" is the \emph{normal} (standard) mode. This mode is able to detect all four types of anomalies. It guarantees that all unique attribute value combinations are identified as anomalies in the most efficient way, but assumes there are not too many attributes (i.e. is vulnerable to the curse of dimensionality).
#'  \item "CA" mode conducts the first iteration only with \emph{categorical} attributes. This mode generally is able to analyze a larger number of attributes than NO (normal) mode and still guarantees that all unique attribute value combinations are identified as anomalies. However, it runs somewhat less efficient than NO mode. Also, the CA mode gives categorical attributes a somewhat higher weight (which can be compensated partially by increasing the MinimumNumberOfIterations if time performance is not an issue). The CA mode assumes there are sufficient continuous attributes (that can be ignored in the first iteration) and that the joint categorical attributes do not yield too many unique combinations (i.e. constellations) in the first iterations. As such, it is still vulnerable to the curse of dimensionality.
#'  \item "IN" mode combines the NO mode with a univariate analysis, which focuses on the \emph{individual} variables separately. The IN mode is able to deal with a large amount of attributes, but is no longer guaranteed to identify unique attribute value combinations as the most extreme anomalies. There are two phases in any given iteration. The \emph{univariate} phase analyzes the individual attributes without taking into account the relationships between them (i.e. combinations of attribute values are ignored). The \emph{multivariate} phase within the iteration does take the relationships between variables into account. SECODA stops running the univariate phase when the number of iterations specified in the StartHeuristicsAfterIteration argument is reached, so the user can decrease this number to give relationships between variables more weight in the analysis. It is recommended to set this setting as low as possible (see StartHeuristicsAfterIteration).
#'  }
#' @param MinimumNumberOfIterations The minimum number of iterations. The algorithm will conduct at least this number of iterations, even if it has converged. This setting can be increased to make the results more precise when running time is not an issue. Standard value is 7, but can be set to a lower value in experimental situations (SECODA will then decide itself if fewer iterations will suffice).
#' @param MaximumNumberOfIterations The maximum number of iterations. The algorithm will conduct at most this number of iterations, even if it has not yet converged the regular way. This can speed up the analysis at the cost of precision. Furthermore, although the algorithm is designed to avoid infinite loops, it is still possible that a certain combination of settings results in an endless loop. The analysis can then be rerun with an acceptable value for MaximumNumberOfIterations.
#' @param StartHeuristicsAfterIteration The iteration after which several heuristics will be applied. These heuristics speed up the process, but make the results somewhat less precise. In HighDimMode "IN" it is recommended to set this argument as low as possible, depending mainly on the precision with which the user wants to discretize the continuous variables. If 5 bins (intervals) is sufficient, the StartHeuristicsAfterIteration argument can be set to 4, if 9 bins is sufficient, StartHeuristicsAfterIteration can be set to 8, et cetera. Also see the DSAA 2017 paper by Foorthuis for information on the pruning heuristic that is triggered when the number of iterations set by this argument is reached.
#' @param FractionOfCasesToRetain The fraction of cases to retain while running the pruning heuristic. The fraction is set as a number between 0 and 1. The pruning will not discard more cases than 1-FractionOfCasesToRetain.
#' @param TestMode The mode for returning information regarding the analysis process. \itemize{
#'   \item "Normal" for only returning the anomaly scores (not the process log) and showing the messages while executing.
#'   \item "FullReturn" for returning the anomaly scores and process log, but not displaying the messages while executing.
#'   \item "FullTest" for returning the anomaly scores and process log, and displaying the messages while executing.
#'   }
#' @param InitialArity The number of discretization intervals (bins) for the first iteration. Standard value is 2 intervals.
#' @import data.table
#' @export
#'
#' @return SECODA returns a data frame containing the ID and an anomaly score for all cases in the original input dataset 'datset'. Low scores represent anomalous cases. The ID is the row number of the case in the original 'datset'. If TestMode is FullReturn or FullTest SECODA returns a list with the process log and the aforementioned data frame containing the IDs and anomaly scores.
#'
#' @examples
#'
#'\dontrun{
#' SECODA(DataSet1)
#'
#' SECODA(DataSet1, MinimumNumberOfIterations = 12, StartHeuristicsAfterIteration = 15) # Make sure at least 12 iterations are run, and, if needed, start heuristics after 15 iterations.
#'
#' SECODA(DataSet1, HighDimMode = "CA") # You can also use "IN", for dealing with high-dimensional datasets.
#'
#' SECODA(DataSet1, BinningMethod = "ED") # Use equidepth (equal frequency) discretization instead of the standard equiwidth (equal interval) discretization.
#'
#' SECODA(DataSet1, TestMode="FullTest") # See messages in the R console.
#'
#' See www.foorthuis.nl for example data files and R code.
#'}


SECODA <- function(datset, BinningMethod="EW", HighDimMode="NO", MinimumNumberOfIterations=7, MaximumNumberOfIterations=99999, StartHeuristicsAfterIteration=10, FractionOfCasesToRetain=0.2, InitialArity=2, TestMode="Normal") {

  # Check hard conditions
  if (MinimumNumberOfIterations > MaximumNumberOfIterations) stop("Argument MinimumNumberOfIterations must be smaller than or equal to MaximumNumberOfIterations.")
  if (StartHeuristicsAfterIteration < MinimumNumberOfIterations) stop("Argument StartHeuristicsAfterIteration must be equal to or greater than MinimumNumberOfIterations.")
  if ( class(datset) != "data.frame") stop("Input datset should be a data.frame.")
  if (BinningMethod != "EW" && BinningMethod != "ED") stop("BinningMethod should be 'EW' (equiwidth) or 'ED' (equidepth).")
  if (HighDimMode != "NO" && HighDimMode != "CA" && HighDimMode != "IN") stop("HighDimMode should be 'NO' (normal), 'CA' (first iteration only analyzes categorical attributes) or 'IN' (combine normal and univariate analysis).")
  if (TestMode != "Normal" && TestMode != "FullReturn" && TestMode != "FullTest") stop("TestMode should 'Normal' (simply return anomaly scores), 'FullReturn' (return anomaly scores and process log, but do not display full messages while running) or 'FullTest'(return anomaly scores and process log, and display full messages while running).")
  if (InitialArity < 2) stop("InitialArity must be an integer greater than or equal to 2.")

  # R settings
  options(digits=22) # After several iterations some anomalies may differ only to a small degree. Make sure that R prints sufficient decimal places if you want to visually compare them.

  # Initialize internal parameters
  SDAnoFraction <- 0.003  # This is 0.3%, the percentage of cases beyond 3 times the standard deviation (i.e. (100-99.7)/100=0.003). This is a standard way to define the fraction of cases in a dataset that can be denoted outliers. This is used as a threshold to determine if we can stop the algorithm, which iterates until it converges when the fraction of anomalies as defined by SDAnoFraction is reached.
  SDAnoFractionInIterationOne <- FALSE  # Whether the SDAnoFraction threshold has already been reached after the first iteration.
  NBreaksCurrent <- InitialArity  # The arity, or the number of intervals to start with for discretization purposes.
  AveAnoScoreStopPoint <- 1 # The threshold against which the fraction of anomalies is being tested. If the fraction of AveAnoScore reaches this threshold, the algorithm converges. We start with 1, which represents that we need to identify 0.3% cases that are totally unique. But this threshold will be increased in later iterations, so as to relax the uniqueness requirement if it is too difficult to find sufficient unique cases.
  StartIteration <- TRUE  # Whether the next iteration should start.
  UniqueCases <- FALSE  # Whether one or more unique cases have already been encountered.
  CurrentIteration <- 0  # The current iteration number.
  VarsTable <- data.frame(VariableName=character(), DataType=character(), stringsAsFactors=FALSE)  # The set of variables (and their datatypes) that is being analyzed.
  AnomalyTable <- data.table(Ano_ID=1:nrow(datset), CurrentFrequency=as.integer(NA), AveAnoScore=as.numeric(NA), stringsAsFactors=FALSE)   # The table that will contain anomaly information.
  AnomalyTabTemp <- data.table(Ano_ID=integer(), AveAnoScore=numeric())  # The table to store the scores of the cases that are pruned away from AnomalyTable.
  Constellations <- vector(mode = "character") # The collection of Constellation IDs.
  AveAnoScore=CurrentFrequencyIN=CurrentFrequency=NULL # Set these variables to NULL, so as to avoid NOTES in the R Build Check.
  if (TestMode != "Normal") { ProgressTable <- data.frame(Iteration=integer(), Arity=integer(), AveAnoScoreStopPoint=numeric(), FractionCurrentFreq=numeric(), FractionAveAnoScore=numeric(), NoCasesAnalyzed=integer() ) } # Log of iterations and fractions (with represent the progress towards the convergence point).

  # Initialize internal function
  PrintResults <- function() {
    # This function prints the results after converging.
    cat(paste0("\nConverged after iteration ", CurrentIteration, "\n"))
    if ( SDAnoFractionInIterationOne == TRUE) cat(paste0("Note: Fraction of ", SDAnoFraction, " anomalies already reached in first iteration. There may be too many variables in the set, too many classes in the categorical variables, or too few rows. It is advised to run SECODA with HighDimMode 'CA' or 'IN'.\n"))
    if (length(VarsTable[VarsTable$DataType=="numerical",1]) > 0) { # If the dataset contains continuous variables.
      cat(paste0("\nCases with an AveAnoScore <= ", AveAnoScoreStopPoint, " may be inspected as potential anomalies\n"))
    } else { # If the dataset contains only categorical variables the AveAnoScoreStopPoint is irrelevant as a threshold.
      cat(paste0("\nCases with low AveAnoScores may be inspected as potential anomalies\n"))
    }
    cat(paste0(" Number of anomalies with score == 1: ", nrow(AnomalyTable[AnomalyTable$AveAnoScore == 1, "Ano_ID", with=FALSE]), "\n"))
    cat(paste0(" Number of anomalies with score <= 2: ", nrow(AnomalyTable[AnomalyTable$AveAnoScore <= 2, "Ano_ID", with=FALSE]), "\n"))
    cat(paste0(" Number of anomalies with score <= 3: ", nrow(AnomalyTable[AnomalyTable$AveAnoScore <= 3, "Ano_ID", with=FALSE]), "\n"))
    if (length(VarsTable[VarsTable$DataType=="numerical",1]) > 0) cat(paste0(" Number of anomalies with score <= ", AveAnoScoreStopPoint, ": ", nrow(AnomalyTable[AnomalyTable$AveAnoScore <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]), "\n\n"))
    # Cases with score <= AveAnoScoreStopPoint can be considered anomalies. The algorithm usually iterates until it converges at a fraction of anomalies of at least the SDAnoFraction.
  }

  # Analyze data types and put in the VarsTable
  for (i in names(datset)) {
    if( sum(is.na(datset[[i]])) != nrow(datset) ) { # Make sure the column is not completely filled with missing values
      if( class(datset[[i]])=="numeric" || class(datset[[i]])=="integer" ) { VarsTable <- rbind(VarsTable, data.frame(VariableName=i, DataType="numerical"))
      } else if (class(datset[[i]])=="factor" || class(datset[[i]])=="character" || class(datset[[i]])=="logical") { VarsTable <- rbind(VarsTable, data.frame(VariableName=i, DataType="categorical"))
      } else { cat(paste0("Warning: Variable '", i, "' of incompatible data type '", class(datset[[i]]), "' is not included in the anomaly detection. The SECODA algorithm may need to be updated.\n")) }
    } else { cat(paste0("Warning: Variable '", i, "' is ignored because it only contains missing values.\n")) }
  }
  VarsTable$VariableName <- as.character(VarsTable$VariableName); VarsTable$DataType <- as.character(VarsTable$DataType)
  if (HighDimMode=="CA" && length(VarsTable[VarsTable$DataType=="categorical",1]) == 0) {
    HighDimMode = "NO"
    cat(paste0("Warning: No categorical attributes found, so switching to HighDimMode 'NO' (normal).\n"))
  }
  if (nrow(VarsTable) > 1) cat(paste0("Starting analysis in mode '", HighDimMode, "' of ", nrow(VarsTable), " variables (", length(VarsTable[VarsTable$DataType=="numerical",1]), " continuous and ", length(VarsTable[VarsTable$DataType=="categorical",1]), " categorical)\n"))
  if (nrow(VarsTable) == 1) cat(paste0("Starting analysis in mode '", HighDimMode, "' of ", nrow(VarsTable), " ", VarsTable$DataType[1], " variable\n"))

  # If HighDimMode is "CA", then count frequencies for the categorical-only constellation. This facilitates the analysis of more attributes in later iterations.
  if (HighDimMode == "CA") {
    if (TestMode == "FullTest") cat(paste0("Processing categorical variables to create frequency-base\n"))
    Constellations <- c(Constellations, paste0("i0CA_Constellation"))  # Add new Constellation variable to set.
    AnomalyTable[, (utils::tail(Constellations,n=1)):=(do.call(paste, c(as.data.frame(datset[AnomalyTable$Ano_ID,VarsTable[VarsTable$DataType=="categorical","VariableName"]]), list(sep=".")))),]   # Create frequency-base with only categorical variables. This should be a subset of all variables, so the frequencies should generally be higher. Too many unique cases in the first iteration(s) should therefore be avoided - or at least be less likely. This thus helps in analyzing more variables, although categorical variables get a somewhat higher weight.
    AnomalyTable[, AveAnoScore:=as.numeric(length(get(utils::tail(Constellations,n=1)))), by=list(unique.values=get(utils::tail(Constellations,n=1)))]   # Insert the frequencies of the constellations in each individual row of AveAnoScore. (With data.table we can do this in one statement.) Convert to numeric (double), since AveAnoScore is numeric.
    UniqueCases = TRUE # The UniqueCases parameter helps in "NO" mode to postpone the analysis in order to speed up the process. However, since the HighDimMode is "CA" creates a base filling of frequencies at the very start, postponing is not possible in this mode. For the remainder of the process, we'll therefore pretend we've already seen unique cases, which will guarantee that no future iterations will be ignored.
  }

  # Start iterations for numerical variables.
  if (TestMode != "FullTest") cat("Iteration: ") # Intro label for short progress report.
  while (StartIteration==TRUE) {

    CurrentIteration = CurrentIteration + 1  # Set the iteration we're currently in.
    if (TestMode == "FullTest") {
      cat(paste0("Starting iteration ", CurrentIteration, "\n"))
    } else {
      cat(" ", CurrentIteration) # Print short progress report
    }
    if (CurrentIteration <= StartHeuristicsAfterIteration) {
      AveAnoScoreStopPoint = AveAnoScoreStopPoint + 0.1  # For e.g. small datasets, start with AveAnoScoreStopPoint 1 and let it increase slowly in order to focus on truly unique and isolated cases (i.e. with a frequency close to 1) in the early iterations, and anomalies with a higher frequency in later iterations (as there are apparently not many unique cases in the set being analyzed). Note also that the 1.1 stop point used in the beginning still only finds truly unique cases in the first iteration (since the first iteration only finds frequencies as real numbers, e.g. 1, 2, 5, 317).
    } else {
      AveAnoScoreStopPoint = AveAnoScoreStopPoint + 1  # If after 10 iterations (StartHeuristicsAfterIteration) the algorithm has not yet converged, relax the convergence threshold. The higher it gets, the less really unique/isolated cases we need to find (as apparently they do not exist or are hard to find).
    } # The higher the AveAnoScoreStopPoint, the less iterations are needed. This threshold is increased each iteration, as apparently a low number takes too long. (A low AveAnoScoreStopPoint may be needed for small datasets or datasets with many unique constellations. In these situations, AveAnoScoreStopPoint=2 is reached very quickly if addition is started already at the first iteration and a high number therefore is not desirable.) We start with AveAnoScoreStopPoint=2, because the lowest theoretical score is 1 (an anomaly is then a case with an AveAnoScore between 1 and 2).
    AnomalyTable$CurrentFrequency <- as.integer(NA)  # Reset. [As integer, since the frequency of a given iteration won't have decimals (as opposed to the average).]
    VarNames <- vector(mode = "character")  # Create empty character vector for the new set of discretized variables that need to be taken into account in the current iteration

    # Discretize all numeric variables by iterating the variable set
    for (i in 1:nrow(VarsTable)) {   # Iterate through numerical variables (integers and numerics).
      if (VarsTable$DataType[i] == "numerical") {
        VarName=paste("i", CurrentIteration, "Discr_", VarsTable$VariableName[i], sep="")  # Create new variable name for the current numeric variable. The first number is the iteration (prefixed with 'i' because column names cannot start with a number), followed by the original variable name.
        if (BinningMethod == "EW") { # Equiwidth discretization (equal interval)
          if (TestMode == "FullTest") { cat(paste(" Starting equiwidth discretization of", VarsTable$DataType[i], "variable", VarsTable$VariableName[i], "into", VarName, "with", NBreaksCurrent, "breaks\n")) }
          AnomalyTable[, (VarName):=as.character(cut(datset[AnomalyTable$Ano_ID,VarsTable$VariableName[i]], breaks = NBreaksCurrent)),] # Create new discretized variable as character. Only for the Ano_ID's in AnomalyTable, which represent (with each iteration's pruning a smaller portion of) the row numbers of the original datset set.
        } else if (BinningMethod == "ED") { # Equidepth discretization (equal frequency)
          if (TestMode == "FullTest") { cat(paste(" Starting equidepth discretization of", VarsTable$DataType[i], "variable", VarsTable$VariableName[i], "into", VarName, "with", NBreaksCurrent, "breaks\n")) }
          nrepl <- floor(nrow(AnomalyTable)/NBreaksCurrent) # Calculate the base frequency for a given bin (some decimals will remain). See https://stackoverflow.com/questions/5731116/equal-frequency-discretization-in-r
          if (NBreaksCurrent %% 2 == 0) { # Test odd/even
            nplus <- seq(from=floor(stats::median(1:NBreaksCurrent))-floor((nrow(AnomalyTable) - nrepl*NBreaksCurrent)/2)+1, length=nrow(AnomalyTable) - nrepl*NBreaksCurrent) # Even: Determine the cases around the middle that will have to hold 1 additional case.  The statement "nrow(AnomalyTable) - nrepl*NBreaksCurrent" gives the number of bins that will have to get 1 extra case in order to be able to bin every case of the entire dataset. The entire statement returns the bin IDs that will get one such extra case.
          } else {
            nplus <- seq(from=floor(stats::median(1:NBreaksCurrent))-floor((nrow(AnomalyTable) - nrepl*NBreaksCurrent)/2), length=nrow(AnomalyTable) - nrepl*NBreaksCurrent) # Odd: The same, but do not add 1 to make sure the bins with an additional case are positioned in the middle.
          }
          nrep <- rep(nrepl,NBreaksCurrent) # Create base frequencies for the bins.
          nrep[nplus] <- nrepl+1 # Correct the bin frequencies so that every case in the dataset can be put into one of the bins.
          NAIDs <- which(is.na(datset[AnomalyTable$Ano_ID,VarsTable$VariableName[i]])) # This identifies the NAs in the original vector.
          AnomalyTable[order(datset[AnomalyTable$Ano_ID,VarsTable$VariableName[i]]), (VarName):=as.character( rep(seq.int(NBreaksCurrent),nrep) ),] # This inserts the bin numbers into a new variable in AnomalyTable.
          AnomalyTable[NAIDs, (VarName):= NA, ] # The NAs have been assigned the highest bin number, so if we want to retain the NAs then we should put them back again.
          rm(nrepl, nplus, nrep, NAIDs)
        }
        VarNames <- c(VarNames, VarName) # Remember all discretized variables
      }
    }

    # If needed, calculate the univariate anomaly score. I.e. without taking into account the interactions between attributes. This helps to deal with high-dimensionality.
    if (HighDimMode == "IN" && CurrentIteration <= StartHeuristicsAfterIteration) {
      if (TestMode == "FullTest") { cat(paste0(" Starting iteration ", CurrentIteration, "'s determination of case-level current univariate frequencies ($CurrentFrequencyIN)\n"  ) ) }
      VarNamesFreq <- vector(mode = "character")  # Create empty character vector for the set of variables containing the frequencies of the variables
      UniqueCases = TRUE # The UniqueCases parameter helps in "NO" mode to postpone the analysis in order to speed up the process. However, since the HighDimMode is "IN" creates base fillings of frequencies in every iteration and we expect high-dimensionality any way, postponing is not desirable in this mode. For the remainder of the process, we'll therefore pretend we've already seen unique cases, which will guarantee that no future iterations will be ignored.
      # Determine frequencies of each discretized numerical attribute:
      for (DiscrVar in VarNames) {
        AnomalyTable[, (paste0(DiscrVar, "Freq")):=length(get(DiscrVar)), by=list(unique.values=get(DiscrVar)) ]  # Put in frequencies for each individual numerical variable.
        VarNamesFreq <- c(VarNamesFreq, paste0(DiscrVar, "Freq"))
      }
      # Determine frequencies of each categorical attribute:
      for (DiscrVar in VarsTable[VarsTable$DataType=="categorical", "VariableName"]) {
        if (class(datset[,DiscrVar]) == "character" || class(datset[,DiscrVar]) == "logical") datset[,DiscrVar] <- as.factor(datset[,DiscrVar])  # Convert variable to factor, so that summary() can be called below. The original variable is converted, to avoid having to repeat this in each iteration.
        AnomalyTable[, (paste0("i", CurrentIteration, DiscrVar, "Freq")):= as.data.frame(summary(datset[,DiscrVar]))[datset[,DiscrVar],]]  # Insert the class frequencies in each row. This statement is only executed before pruning, so we can use the full datset table (otherwise this statement is needed: datset[AnomalyTable$Ano_ID,DiscrVar] )
        VarNamesFreq <- c(VarNamesFreq, paste0("i", CurrentIteration, DiscrVar, "Freq"))
      }
      # Calculate average frequency of the individually determined categorical and discretized numerical attributes
      AnomalyTable[, CurrentFrequencyIN:=(rowSums(AnomalyTable[,VarNamesFreq, with=FALSE])/length(VarNamesFreq))]
      AnomalyTable <- AnomalyTable[,!VarNamesFreq, with=FALSE]; rm(VarNamesFreq) # Discard the temporary columns containing the individual frequencies (of which the names are stored in VarNamesFreq)
    }

    # Determine the constellation for each case
    Constellations <- c(Constellations, paste0("i", CurrentIteration, "Constellation"))  # Add new Constellation variable to set.
    AnomalyTable[, (utils::tail(Constellations,n=1)):=(paste(do.call(paste, c(AnomalyTable[, eval(VarNames), with=FALSE], list(sep="."))), do.call(paste, c(as.data.frame(datset[AnomalyTable$Ano_ID,VarsTable[VarsTable$DataType=="categorical","VariableName"]]), list(sep="."))), sep=".")),] # Insert constellation into new Constellation variable. Use, first, the discretized numerical vars from the AnomalyTable and, second, the original categorical variables from the datset table. For the second (categorical) part the original datset table is used, so we need to give AnomalyTable$Ano_ID as an input to identify the rows because in later iterations the AnomalyTable contains fewer cases.

    # Determine individual anomaly score by counting the total number of cases present in the individual case's constellation.
    if (TestMode == "FullTest") { cat(paste0(" Starting iteration ", CurrentIteration, "'s determination of case-level current combination-based frequencies ($CurrentFrequency)\n"  ) ) }
    AnomalyTable[, CurrentFrequency:=length(get(utils::tail(Constellations,n=1))), by=list(unique.values=get(utils::tail(Constellations,n=1)))]  # Put in the frequencies of the constellations in each individual row. (With data.table we can do this in one statement, instead of creating a separate frequencies table and subsequently doing an inner join on the constellation.)
    if ( UniqueCases == FALSE && min(AnomalyTable$CurrentFrequency)<=1 ) { UniqueCases = TRUE }

    # Calculate the average anomaly score, based on the average and the current frequency
    if (TestMode == "FullTest") { cat(paste0(" Starting iteration ", CurrentIteration, "'s calculation of case-level average anomaly scores ($AveAnoScore)\n"  ) ) }
    if (HighDimMode != "IN" || CurrentIteration > StartHeuristicsAfterIteration) {
      if ((CurrentIteration == 1 && HighDimMode != "CA") || UniqueCases == FALSE ) {
        AnomalyTable$AveAnoScore <- AnomalyTable$CurrentFrequency  # The first iteration does not have an existing average yet (unless HighDimMode is "CA"), so the frequency just gets inserted. Do the same if no unique combinations have yet been found. This latter tactic ensures that iterations in which no unique cases exist can be ignored so as to speed up the process (their score in AnomalyTable$AveAnoScore may be overwritten, although the last iteration without unique combinations will be used in the calculation of the average AveAnoScore). Iterations with non-unique cases can be ignored since they don't contain information about anomalies yet, but can be expected to result in high average scores that need to be brought down (which will require extra iterations).  Once unique combinations are encountered, no iterations will be ignored anymore.
        if (CurrentIteration>1 && TestMode == "FullTest") { cat(paste0(" No unique cases found yet; ignoring (previous) CurrentFrequency\n")) }  # Apparently we have not yet encountered unique cases after iteration 1.
      } else {
        AnomalyTable$AveAnoScore <- rowMeans(cbind(AnomalyTable$AveAnoScore, AnomalyTable$CurrentFrequency), na.rm = TRUE)  # Calculate mean of two vectors, the existing average and the newly calculated frequency of the current iteration. Note that the current frequency weighs as much as (the average of) all other iterations combined.   http://stackoverflow.com/questions/3497464/element-wise-mean-in-r
      }
    } else { # If HighDimMode == "IN" and the heuristics are not being applied yet
      AnomalyTable$AveFreqIN <- rowMeans(cbind(AnomalyTable$CurrentFrequency, AnomalyTable$CurrentFrequencyIN))  # Calculate mean of multivariate (combination-based) and univariate frequency
      WeightIN <- ((StartHeuristicsAfterIteration-CurrentIteration+1)/StartHeuristicsAfterIteration)/2  # Determine the weight of the univariate AveFreqIN. We want to gradually decrease this weight up until we start the heuristics in the iteration set in StartHeuristicsAfterIteration. A constant weight would be 50%, therefore we divide by 2 in the end.
      AnomalyTable$AveAnoScore <- rowMeans(cbind((AnomalyTable$AveAnoScore*(1-WeightIN)), (AnomalyTable$AveFreqIN*WeightIN)), na.rm=TRUE)  # Calculate mean of previous and current iteration
    }

    # Iteration management: Reset variables
    if (TestMode != "FullTest") { AnomalyTable <- AnomalyTable[ , !(names(AnomalyTable) %in% c(VarNames, Constellations)), with=FALSE] }  # Drop the individual discretized variables and constellation description if you're not interested in them.
    if ( CurrentIteration == 1 && ((nrow(AnomalyTable[AnomalyTable$AveAnoScore <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]) / nrow(datset)) > SDAnoFraction ) )  SDAnoFractionInIterationOne <- TRUE

    # Logging
    if (TestMode == "FullTest") {
      cat(paste0(" Fraction of anomalies in $AveAnoScore ", (nrow(AnomalyTable[AnomalyTable$AveAnoScore <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]) / nrow(datset)), "\n")); cat(paste0(" Fraction of anomalies in $CurrentFreq ", (nrow(AnomalyTable[AnomalyTable$CurrentFrequency  <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]) / nrow(datset)), "\n"))
    }

    # Verify if the algorithm has converged. This is the case if there are no continuous variables, if the maximum number of iterations is reached, or if a sufficient fraction of anomalies has been detected.
    if ( length(VarsTable[VarsTable$DataType=="numerical",1]) == 0 || CurrentIteration >= MaximumNumberOfIterations || (CurrentIteration >= MinimumNumberOfIterations && ((nrow(AnomalyTable[AnomalyTable$AveAnoScore <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]) / nrow(datset)) > SDAnoFraction )) ) {  # Verify if the fraction of anomalies (which have a score <= the stop point) is larger than the set fraction (0.003) for the original dataset. If so, we have a sufficiently detailed average anomaly score.
      # ! OOK PROBEREN: plus/minus 2.5 times the standard deviation, zou iets moeten zijn van: (100-98.8)/100=0.012  ]
      StartIteration = FALSE  # The algorithm has converged, so a new iteration is not needed.
      PrintResults() # Print final results
    }

    # Log if you need to retain the process info in the ProgressTable:
    if (TestMode != "Normal") { ProgressTable <- rbind(ProgressTable, data.frame(Iteration=CurrentIteration, Arity=NBreaksCurrent, AveAnoScoreStopPoint=AveAnoScoreStopPoint, FractionCurrentFreq=(nrow(AnomalyTable[AnomalyTable$CurrentFrequency <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]) / nrow(datset)), FractionAveAnoScore=(nrow(AnomalyTable[AnomalyTable$AveAnoScore <= AveAnoScoreStopPoint, "Ano_ID", with=FALSE]) / nrow(datset)), NoCasesAnalyzed=nrow(AnomalyTable) )) }

    # Update the discretization parameters for the next iteration.
    if (CurrentIteration <= StartHeuristicsAfterIteration) {
      NBreaksCurrent = NBreaksCurrent + 1  # In the first 10 iterations (StartHeuristicsAfterIteration) simply add 1 cut point.
    } else {
      NBreaksCurrent = NBreaksCurrent + (floor(AveAnoScoreStopPoint) - 2) # After 10 iterations the algorithm apparently has not converged yet, so let the number of cut points increase with increasingly larger steps. We will accept a slight increase in arbitrariness of the ranking as a result of bigger leaps and thus some loss of information (the negative effects can be expected to be small, as the most important information has already been gathered in previous iterations). We simply re-use AveAnoScoreStopPoint here (or at least the floor() to ensure it's an integer and not a decimal) to have the NBreaksCurrent increase faster (but detract 2 to start at 0, since AveAnoScoreStopPoint has already increased to 2 the first time we want to take larger steps).
    }

    # Run the pruning heuristic after 10 iterations (StartHeuristicsAfterIteration) to speed up the next iteration: discard the cases that are very unlikely to be later identified as anomalies. Do not prune away more than set in FractionOfCasesToRetain (standard not more than 80%).
    if (CurrentIteration > StartHeuristicsAfterIteration && StartIteration==TRUE && nrow(AnomalyTable)/nrow(datset) >= FractionOfCasesToRetain) {
      ToRetain <- as.integer(AnomalyTable[AnomalyTable$AveAnoScore < stats::quantile(AnomalyTable$AveAnoScore, prob=0.95, names=FALSE), "Ano_ID", with=FALSE]$Ano_ID) # Store the IDs of cases to retain.
      AnomalyTabTemp <- rbind(AnomalyTabTemp, AnomalyTable[!(AnomalyTable$Ano_ID %in% ToRetain), c("Ano_ID", "AveAnoScore"), with=FALSE])  # Add to AnomalyTabTemp the scores of the cases that will be discarded from AnomalyTable (and will thus not be analyzed anymore in future iterations).
      AnomalyTable <- AnomalyTable[AnomalyTable$Ano_ID %in% ToRetain, ]   # Delete the 5% rows with the hitherto highest average anomaly score, i.e. discard the cases that at this time seem to be the most normal (most frequent). Note, however, that often more than this percentage will actually be discarded. The reason for this is the fact that normal cases are abundant, and thus many records around the specified quantile have the same AveAnoScore.
      if (TestMode == "FullTest") { cat(paste0(" Discarded ", nrow(datset)-nrow(AnomalyTable), " cases (", round(100-nrow(AnomalyTable)/nrow(datset)*100, digits = 2), "%)", " to speed up the next iteration.\n")) }
    } else if (CurrentIteration > StartHeuristicsAfterIteration && StartIteration==TRUE && nrow(AnomalyTable)/nrow(datset) < FractionOfCasesToRetain ) {
      if (nrow(AnomalyTable)/nrow(datset) < SDAnoFraction) { # In this extreme situation the algorithm needs to stop to prevent an endless loop. Almost all cases are discarded (even more than the theoretically expected amount of 'normal' cases), probably because of a highly skewed dataset. After pruning so much, the algorithm may not converge anymore, so we stop it.
        StartIteration = FALSE
        if (TestMode == "FullTest") cat(paste0("\nDiscarded most of the cases in previous pruning action(s) (", round(100-nrow(AnomalyTable)/nrow(datset)*100, digits = 2), "%), so stopping analysis process."))
        PrintResults() # Print final results
      } else {
        if (TestMode == "FullTest") cat(paste0(" Not discarded any cases, as over 80% has already been pruned away.\n")) # Continue analysis without pruning.
      }
    }

  } # End iterations for numerical variables

  # Combine the scores of the cases left in AnomalyTable and the discarded cases in AnomalyTabTemp. Note that the scores of the discarded cases are higher than they would have been without pruning, as later iterations could not bring down these scores.
  AnomalyTabTemp <- rbind(AnomalyTabTemp, AnomalyTable[, c("Ano_ID", "AveAnoScore"), with=FALSE])
  AnomalyTabTemp <- AnomalyTabTemp[with(AnomalyTabTemp, order(Ano_ID)), ]  # Sort on Ano_ID
  if (TestMode == "Normal") {
    return(as.data.frame(AnomalyTabTemp))  # Return only the anomaly scores as a data.frame
  } else {
    ReturnList <- list("AnomalyScores"=as.data.frame(AnomalyTabTemp), "VariableTable"=VarsTable, "ProgressTable"=ProgressTable)
    return(ReturnList)  # Return a list with the anomaly scores, variable overview and the process information in three data.frames
  }
}
